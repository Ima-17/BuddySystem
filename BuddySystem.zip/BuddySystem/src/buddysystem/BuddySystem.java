package buddysystem;
import java.util.ArrayList;
import java.util.List;

public class BuddySystem {
    private final int totalMemory;  // Total memory in the system
    private final List<MemoryBlock> memoryBlocks; // List of memory blocks

    // Constructor
    public BuddySystem(int totalMemory) {
        this.totalMemory = totalMemory;
        this.memoryBlocks = new ArrayList<>();
        // Initialize with one large free block
        memoryBlocks.add(new MemoryBlock(totalMemory, 0));
    }

    // Allocate memory
    public void allocateMemory(int requestSize) {
        for (MemoryBlock block : memoryBlocks) {
            if (block.isFree && block.size >= requestSize) {
                while (block.size > requestSize) {
                    splitBlock(block); // Split until size matches
                }
                block.isFree = false;
                System.out.println("Allocated " + requestSize + " bytes at address " + block.startAddress);
                return;
            }
        }
        System.out.println("Allocation failed: Not enough memory.");
    }

    // Split a block into two smaller buddies
    private void splitBlock(MemoryBlock block) {
        int newSize = block.size / 2;
        memoryBlocks.add(new MemoryBlock(newSize, block.startAddress + newSize));
        block.size = newSize;
        System.out.println("Split block into two buddies of size " + newSize);
    }

    // Free memory at a given address
    public void freeMemory(int startAddress) {
        for (MemoryBlock block : memoryBlocks) {
            if (block.startAddress == startAddress) {
                block.isFree = true;
                System.out.println("Freed memory at address " + startAddress);
                mergeBuddies();
                return;
            }
        }
        System.out.println("Invalid address: No allocation found.");
    }

    // Merge buddies if possible
    private void mergeBuddies() {
        for (int i = 0; i < memoryBlocks.size(); i++) {
            MemoryBlock block1 = memoryBlocks.get(i);
            if (!block1.isFree) continue;

            for (int j = i + 1; j < memoryBlocks.size(); j++) {
                MemoryBlock block2 = memoryBlocks.get(j);
                if (block2.isFree && block1.size == block2.size &&
                    (block1.startAddress ^ block2.startAddress) == block1.size) {
                    block1.size *= 2;
                    memoryBlocks.remove(block2);
                    System.out.println("Merged blocks to form size " + block1.size);
                    mergeBuddies();
                    return;
                }
            }
        }
    }

    // Display the current state of memory
    public void displayMemory() {
        System.out.println("Current memory state:");
        for (MemoryBlock block : memoryBlocks) {
            System.out.println("Block at " + block.startAddress + ", Size: " + block.size + ", Free: " + block.isFree);
        }
    }
}