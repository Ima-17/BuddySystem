package buddysystem;

public class Main {

	public Main() {
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 BuddySystem buddySystem = new BuddySystem(128); // Total memory is 128 bytes.

	        System.out.println("Initial memory state:");
	        buddySystem.displayMemory();

	        buddySystem.allocateMemory(32); // Request 32 bytes.
	        buddySystem.displayMemory();

	        buddySystem.allocateMemory(16); // Request 16 bytes.
	        buddySystem.displayMemory();

	        buddySystem.freeMemory(0); // Free memory at address 0.
	        buddySystem.displayMemory();

	        buddySystem.allocateMemory(64); // Request 64 bytes.
	        buddySystem.displayMemory();

	}

}
