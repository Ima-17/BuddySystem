package buddysystem;

public class MemoryBlock {
	int size;          // Size of the memory block
    boolean isFree;    // Whether the block is free
    int startAddress;  // Starting address of the block

    // Constructor
    public MemoryBlock(int size, int startAddress) {
        this.size = size;
        this.startAddress = startAddress;
        this.isFree = true; // Block is free by default
    }
}
