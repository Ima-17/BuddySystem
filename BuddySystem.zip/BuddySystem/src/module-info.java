/**
 * 
 */
/**
 * 
 */
module BuddySystem {
}